<?php
    $connection = mysqli_connect("localhost","root","","selection_committee_db");
?>
